# 🗿 Concrete.xyz Community Hub — Streamlit App

Bilingual (English + اردو) Streamlit app for the Concrete.xyz community.

## Features
- 📝 **Quiz** — 15 questions, 6 random per session, leaderboard
- 🏦 **Vaults** — Live vault data with chain filter
- 🛠️ **Tools** — Community-built tools directory
- 👜 **Bags** — Earn Bags campaign guide
- 🏅 **Leaderboard** — Quiz rankings
- 🎨 **Art Gallery** — Upload & display community art

## Deploy on Streamlit Cloud

1. Push this folder to a GitHub repo
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your repo → set main file: `app.py`
4. Done! 🚀

## Local Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Builder
**mkashifalikcp** — Community contributor, Concrete.xyz
